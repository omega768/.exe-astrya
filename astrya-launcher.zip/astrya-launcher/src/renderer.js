const activationForm = document.getElementById('activation-form');
const keyInput = document.getElementById('key-input');
const activateButton = document.getElementById('activate-button');
const btnText = activateButton?.querySelector('.btn-text');
const loadingSpinner = document.getElementById('loading-spinner');
const activationError = document.getElementById('activation-error');
const gameResult = document.getElementById('game-result');
const gameImage = document.getElementById('game-image');
const gameName = document.getElementById('game-name');
const gameActivationState = document.getElementById('game-activation-state');
const installButton = document.getElementById('install-button');
const progressCard = document.getElementById('download-progress');
const progressFill = document.getElementById('progress-fill');
const progressStage = document.getElementById('progress-stage');
const progressTime = document.getElementById('progress-time');
const steamDirButton = document.getElementById('steam-dir-button');
const fixButton = document.getElementById('fix-button');
const discordButton = document.getElementById('discord-support-button');
const fixModal = document.getElementById('fix-modal');
const fixRun = document.getElementById('fix-run');
const rememberCheckbox = document.getElementById('remember-key');
const termsLink = document.getElementById('terms-link');
const privacyLink = document.getElementById('privacy-link');
const confirmModal = document.getElementById('confirm-modal');
const confirmYes = document.getElementById('confirm-yes');
const confirmNo = document.getElementById('confirm-no');
const confirmMessage = document.getElementById('confirm-message');

let currentGame = null;
let progressStartedAt = null;
let progressTimer = null;
let pendingInstall = null;

// Carregar key salva
const savedKey = localStorage.getItem('saved_key');
if (savedKey && keyInput) {
  keyInput.value = savedKey;
  if (rememberCheckbox) rememberCheckbox.checked = true;
}

function setActivationError(message) {
  if (!activationError) return;
  if (message) {
    activationError.textContent = message;
    activationError.classList.remove('hidden');
  } else {
    activationError.classList.add('hidden');
    activationError.textContent = '';
  }
}

function resetProgress() {
  if (!progressCard) return;
  progressCard.classList.add('hidden');
  if (progressFill) progressFill.style.width = '0%';
  if (progressStage) progressStage.textContent = 'Validando sua key...';
  if (progressTime) progressTime.textContent = '00:00';
  if (progressTimer) clearInterval(progressTimer);
  progressStartedAt = null;
}

function updateProgress(stage, message) {
  if (!progressCard) return;
  const stageMap = {
    start: { label: 'Validando sua key...', percent: 8 },
    downloading: { label: 'Baixando arquivos...', percent: 52 },
    extracting: { label: 'Extraindo arquivos...', percent: 90 },
    done: { label: 'Instalação concluída!', percent: 100 }
  };
  const info = stageMap[stage] || { label: message || 'Processando...', percent: 40 };
  progressCard.classList.remove('hidden');
  if (!progressStartedAt) {
    progressStartedAt = Date.now();
    progressTimer = setInterval(() => {
      if (progressTime && progressStartedAt) {
        const elapsed = Math.floor((Date.now() - progressStartedAt) / 1000);
        const minutes = String(Math.floor(elapsed / 60)).padStart(2, '0');
        const seconds = String(elapsed % 60).padStart(2, '0');
        progressTime.textContent = `${minutes}:${seconds}`;
      }
    }, 1000);
  }
  if (progressStage) progressStage.textContent = info.label;
  if (progressFill) progressFill.style.width = `${info.percent}%`;
  if (stage === 'done') setTimeout(() => resetProgress(), 4000);
}

function showLoading(show) {
  if (!btnText || !loadingSpinner || !activateButton) return;
  if (show) {
    btnText.textContent = 'Validando...';
    loadingSpinner.classList.remove('hidden');
    activateButton.disabled = true;
  } else {
    btnText.textContent = 'Ativar Key';
    loadingSpinner.classList.add('hidden');
    activateButton.disabled = false;
  }
}

async function handleActivation(keyValue) {
  const key = (keyValue || '').trim();
  if (!key) {
    setActivationError('Digite uma key válida.');
    return;
  }
  setActivationError('');
  showLoading(true);
  
  try {
    const result = await window.api.activateKey(key);
    
    if (!result || !result.success || !result.game) {
      setActivationError(result?.message || 'Key inválida.');
      return;
    }
    
    // Salvar key se checkbox marcado
    if (rememberCheckbox && rememberCheckbox.checked) {
      localStorage.setItem('saved_key', key);
    } else {
      localStorage.removeItem('saved_key');
    }
    
    currentGame = result.game;
    
    gameResult.classList.remove('hidden');
    gameName.textContent = currentGame.name || 'Jogo Astrya';
    gameActivationState.classList.remove('hidden');
    gameActivationState.textContent = '✓ Ativado com sucesso';
    
    if (currentGame.image_url && currentGame.image_url !== '') {
      gameImage.src = currentGame.image_url;
    } else {
      gameImage.src = 'assets/astrya-logo.ico';
    }
    
    installButton.disabled = false;
    
  } catch (err) {
    setActivationError(err.message || 'Erro ao validar key.');
  } finally {
    showLoading(false);
  }
}

function showConfirmDialog(message, onConfirm) {
  if (!confirmModal || !confirmMessage) return;
  confirmMessage.textContent = message;
  pendingInstall = onConfirm;
  confirmModal.classList.remove('hidden');
}

if (confirmYes) {
  confirmYes.addEventListener('click', () => {
    confirmModal.classList.add('hidden');
    if (pendingInstall) {
      pendingInstall();
      pendingInstall = null;
    }
  });
}

if (confirmNo) {
  confirmNo.addEventListener('click', () => {
    confirmModal.classList.add('hidden');
    pendingInstall = null;
  });
}

if (installButton) {
  installButton.addEventListener('click', async () => {
    if (!currentGame) return;
    showConfirmDialog(`Deseja instalar ${currentGame.name}?`, async () => {
      installButton.disabled = true;
      installButton.textContent = 'Instalando...';
      try {
        await window.api.downloadGame(currentGame);
        installButton.textContent = 'Instalação concluída!';
      } catch (err) {
        console.error(err);
        installButton.textContent = 'Erro ao instalar';
      } finally {
        installButton.disabled = false;
      }
    });
  });
}

if (steamDirButton) steamDirButton.addEventListener('click', () => window.api.chooseSteamDir());
if (fixButton) fixButton.addEventListener('click', () => fixModal?.classList.remove('hidden'));
if (discordButton) discordButton.addEventListener('click', () => window.api.openExternal('https://discord.gg/kj9fDUwYGK'));
if (fixRun) fixRun.addEventListener('click', async () => { await window.api.runFixCommand(); fixModal?.classList.add('hidden'); });
if (fixModal) fixModal.addEventListener('click', (e) => { if (e.target === fixModal) fixModal.classList.add('hidden'); });
if (termsLink) termsLink.addEventListener('click', () => window.api.openExternal('https://astrya.com/terms'));
if (privacyLink) privacyLink.addEventListener('click', () => window.api.openExternal('https://astrya.com/privacy'));

if (activationForm) {
  activationForm.addEventListener('submit', (event) => {
    event.preventDefault();
    handleActivation(keyInput?.value);
  });
}

window.api.onDownloadProgress((payload) => {
  if (payload && currentGame) {
    updateProgress(payload.stage, payload.message);
  }
});

// Criar bolinhas caindo via JavaScript
function createSnowflakes() {
  const snowfallDiv = document.createElement('div');
  snowfallDiv.style.position = 'fixed';
  snowfallDiv.style.top = '0';
  snowfallDiv.style.left = '0';
  snowfallDiv.style.width = '100%';
  snowfallDiv.style.height = '100%';
  snowfallDiv.style.pointerEvents = 'none';
  snowfallDiv.style.zIndex = '999';
  snowfallDiv.style.overflow = 'hidden';
  document.body.appendChild(snowfallDiv);

  for (let i = 0; i < 80; i++) {
    const snowflake = document.createElement('div');
    snowflake.style.position = 'absolute';
    snowflake.style.top = '-10px';
    snowflake.style.left = Math.random() * 100 + '%';
    snowflake.style.width = Math.random() * 6 + 3 + 'px';
    snowflake.style.height = snowflake.style.width;
    snowflake.style.background = '#fff';
    snowflake.style.borderRadius = '50%';
    snowflake.style.opacity = Math.random() * 0.5 + 0.3;
    snowflake.style.boxShadow = '0 0 4px #c6a8ff';
    snowflake.style.animation = `fallSnow ${Math.random() * 5 + 3}s linear infinite`;
    snowflake.style.animationDelay = Math.random() * 5 + 's';
    snowfallDiv.appendChild(snowflake);
  }

  // Adicionar keyframe animation via JavaScript
  const style = document.createElement('style');
  style.textContent = `
    @keyframes fallSnow {
      0% {
        transform: translateY(-10px);
        opacity: 0;
      }
      10% {
        opacity: 1;
      }
      100% {
        transform: translateY(100vh);
        opacity: 0;
      }
    }
  `;
  document.head.appendChild(style);
}

// Executar quando a página carregar
window.addEventListener('DOMContentLoaded', createSnowflakes);
