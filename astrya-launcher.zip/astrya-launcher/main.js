const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const { exec } = require('child_process');
const AdmZip = require('adm-zip');
const { createClient } = require('@supabase/supabase-js');

// DESABILITA FFMPEG COMPLETAMENTE (remove o erro)
app.commandLine.appendSwitch('disable-ffmpeg');
app.disableHardwareAcceleration();

const SUPABASE_URL = 'https://egxndzdwtdaeiwokwrfm.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVneG5kemR3dGRhZWl3b2t3cmZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwNDg4MjIsImV4cCI6MjA5MTYyNDgyMn0.NZEiP-l9RTE7SFJBgfC14AfMufY-uRFf4P4FxYl1M2s';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let mainWindow;
let steamDir = "C:/Program Files (x86)/Steam";

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    frame: false,
    transparent: true,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
    icon: path.join(__dirname, 'src', 'assets', 'astrya-logo.ico')
  });
  mainWindow.loadFile('src/index.html');
  mainWindow.setBackgroundColor('#00000000');
}

ipcMain.handle('activate-key', async (event, key) => {
  try {
    const { data: keyData, error } = await supabase
      .from('game_keys')
      .select('*, games(*)')
      .eq('chave', key)
      .eq('ativo', false)
      .single();

    if (error || !keyData) {
      return { success: false, message: 'Chave inválida ou já utilizada' };
    }

    if (keyData.expires_at && new Date() > new Date(keyData.expires_at)) {
      return { success: false, message: 'Chave expirada' };
    }

    await supabase
      .from('game_keys')
      .update({ ativo: true, activated_at: new Date().toISOString() })
      .eq('id', keyData.id);

    return {
      success: true,
      game: {
        id: keyData.games.id,
        name: keyData.games.name,
        zip_url: keyData.games.zip_url,
        image_url: keyData.games.image_url
      }
    };
  } catch (error) {
    return { success: false, message: error.message };
  }
});

ipcMain.handle('download-game', async (event, game) => {
  const steamGamePath = path.join(steamDir, 'steamapps', 'common', game.name);
  
  if (!fs.existsSync(steamGamePath)) {
    fs.mkdirSync(steamGamePath, { recursive: true });
  }
  
  const zipPath = path.join(steamGamePath, 'game.zip');
  
  mainWindow.webContents.send('download-progress', {
    appid: game.id,
    stage: 'downloading',
    message: 'Baixando arquivos...'
  });
  
  const response = await axios({
    method: 'GET',
    url: game.zip_url,
    responseType: 'stream'
  });
  
  const writer = fs.createWriteStream(zipPath);
  response.data.pipe(writer);
  
  return new Promise((resolve, reject) => {
    writer.on('finish', () => {
      mainWindow.webContents.send('download-progress', {
        appid: game.id,
        stage: 'extracting',
        message: 'Extraindo arquivos...'
      });
      
      const zip = new AdmZip(zipPath);
      zip.extractAllTo(steamGamePath, true);
      fs.unlinkSync(zipPath);
      
      mainWindow.webContents.send('download-progress', {
        appid: game.id,
        stage: 'done',
        message: 'Instalação concluída!'
      });
      
      resolve({ success: true });
    });
    writer.on('error', reject);
  });
});

ipcMain.handle('get-steam-dir', async () => ({ baseDir: steamDir }));
ipcMain.handle('choose-steam-dir', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] });
  if (!result.canceled && result.filePaths[0]) {
    steamDir = result.filePaths[0];
    return { baseDir: steamDir };
  }
  return { cancelled: true };
});
ipcMain.handle('close-steam', async () => { exec('taskkill /f /im steam.exe', () => {}); return { success: true }; });
ipcMain.handle('open-steam', async () => { exec('start steam://open/console', () => {}); return { success: true }; });
ipcMain.handle('run-fix-command', async () => ({ ok: true, message: "Fix executado" }));
ipcMain.handle('open-external', async (event, url) => { shell.openExternal(url); });
ipcMain.handle('get-user-games', async () => ({ success: true, games: [] }));
ipcMain.handle('get-installations', async () => ({}));
ipcMain.handle('cleanup-temp', async () => ({ ok: true }));
ipcMain.handle('repair-installations', async () => ({ ok: true }));
ipcMain.handle('search-games', async () => ({ success: true, games: [] }));
ipcMain.handle('get-user-profile', async () => ({ success: true, user: { email: "usuario@astrya.com" }, games: [] }));

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
